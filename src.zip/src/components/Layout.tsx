import React, { useState, useEffect } from 'react';
import { Briefcase, Calendar, BookOpen, ListTodo, LogOut, Menu, X, LayoutDashboard, FileSignature, GraduationCap, Search, MapPin, ClipboardCheck, ScrollText, Download, PieChart, Bell, ShieldCheck } from 'lucide-react';
import { User } from '../types';

export interface Notification {
    id: string;
    text: string;
    targetTab: string;
    contextData?: string; // e.g. pitchId
    type: 'info' | 'warning' | 'success';
}

interface LayoutProps {
  children: React.ReactNode;
  user: User;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  notifications?: Notification[];
  onClearNotification?: (id: string) => void;
  onNavigateWithContext?: (tab: string, contextId?: string) => void;
}

// Matching SVG Logo for Sidebar (Smaller)
const Logo = () => (
    <svg width="32" height="32" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-lg">
        <rect width="48" height="48" rx="12" fill="url(#paint0_linear_logo_layout)" />
        <path d="M24 34L11 13H17.5L24 24.5L30.5 13H37L24 34Z" fill="white"/>
        <path d="M24 6V10" stroke="white" strokeWidth="2" strokeLinecap="round"/>
        <defs>
            <linearGradient id="paint0_linear_logo_layout" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
                <stop stopColor="#2563EB"/>
                <stop offset="1" stopColor="#06B6D4"/>
            </linearGradient>
        </defs>
    </svg>
);

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout, activeTab, setActiveTab, notifications = [], onClearNotification, onNavigateWithContext }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true) {
      setIsInstalled(true);
    }
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    if ((window as any).deferredPrompt) setDeferredPrompt((window as any).deferredPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    setDeferredPrompt(null);
    if (outcome === "accepted") setIsInstalled(true);
  };

  const handleNotifClick = (n: Notification) => {
      if (onNavigateWithContext) {
        onNavigateWithContext(n.targetTab, n.contextData);
      } else {
        setActiveTab(n.targetTab);
      }
      if (onClearNotification) onClearNotification(n.id);
      setIsNotifOpen(false);
  };

  const founderItems = [
    { id: 'dashboard', label: 'Command Center', icon: LayoutDashboard },
    { id: 'pitch', label: 'Pitch Deck', icon: Briefcase },
    { id: 'meetings', label: 'Meetings', icon: Calendar },
    { id: 'diligence', label: 'Due Diligence', icon: MapPin },
    { id: 'contract', label: 'Legal', icon: FileSignature },
    { id: 'bootcamp', label: 'Bootcamp', icon: GraduationCap },
    { id: 'resources', label: 'Knowledge Base', icon: BookOpen },
    { id: 'roadmap', label: 'Execution', icon: ListTodo },
  ];

  const investorItems = [
    { id: 'analyst-ventures', label: 'Venture Pipeline', icon: Search },
    { id: 'analyst-analysis', label: 'Meeting Prep', icon: ClipboardCheck },
    { id: 'analyst-diligence', label: 'Due Diligence', icon: MapPin },
    { id: 'analyst-contracts', label: 'Contracts', icon: ScrollText },
    { id: 'dashboard', label: 'Portfolio', icon: PieChart },
  ];

  const items = user.role === 'founder' ? founderItems : investorItems;
  const currentItem = items.find(i => i.id === activeTab);

  return (
    <div className="min-h-screen bg-slate-50 font-sans flex flex-col md:flex-row">
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-40 md:hidden" onClick={() => setIsSidebarOpen(false)} />
      )}
      
      {/* Sidebar - Deep Dark Theme - Fixed on Desktop, Slide on Mobile */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-72 bg-slate-900 text-slate-300 flex flex-col shadow-2xl transition-transform duration-300 md:relative md:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} border-r border-slate-800`}>
        
        {/* Logo Area */}
        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo />
            <div>
                <h1 className="text-lg font-bold text-white tracking-tight">Vett & Venture</h1>
                <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest">Platform</p>
            </div>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="md:hidden p-1 text-slate-400 hover:text-white transition-colors"><X size={20} /></button>
        </div>
        
        <div className="px-6 py-2">
            <div className="text-[10px] uppercase tracking-wider font-semibold text-slate-500 mb-2">Main Menu</div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto px-4 space-y-1">
            {items.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setIsSidebarOpen(false); }}
                  className={`group w-full flex items-center justify-between px-4 py-3 rounded-lg transition-all duration-200 ${isActive ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50' : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'}`}
                >
                    <div className="flex items-center space-x-3">
                        <Icon size={18} className={isActive ? 'text-white' : 'text-slate-500 group-hover:text-white transition-colors'} />
                        <span className="font-medium text-sm">{item.label}</span>
                    </div>
                    {isActive && <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></div>}
                </button>
              );
            })}
        </nav>

        {/* Install Button */}
        {!isInstalled && deferredPrompt && (
          <div className="px-4 mb-4">
            <button onClick={handleInstallClick} className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white py-3 rounded-lg font-bold shadow-lg shadow-emerald-900/20 transition-all text-sm">
              <Download size={16} /><span>Install App</span>
            </button>
          </div>
        )}

        {/* User Profile */}
        <div className="p-4 border-t border-slate-800 bg-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-slate-700 flex items-center justify-center border border-slate-600">
                <span className="font-bold text-white text-xs">{user.name.charAt(0)}</span>
            </div>
            <div className="flex-1 overflow-hidden">
                <p className="text-sm font-semibold text-white truncate">{user.name}</p>
                <p className="text-xs text-slate-500 truncate capitalize">{user.role}</p>
            </div>
            <button onClick={onLogout} className="p-2 text-slate-400 hover:text-white transition-colors rounded-md hover:bg-slate-800" title="Sign Out">
                <LogOut size={16} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area - Native Scroll */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-50/50 min-h-screen">
        {/* Top Header */}
        <header className="h-16 glass sticky top-0 z-30 flex items-center justify-between px-4 md:px-8 flex-shrink-0">
            <div className="flex items-center">
                <button onClick={() => setIsSidebarOpen(true)} className="mr-4 p-2 -ml-2 text-slate-600 hover:bg-slate-100 rounded-lg md:hidden"><Menu size={20} /></button>
                <div className="hidden md:flex flex-col">
                    <h2 className="text-sm font-bold text-slate-900">{currentItem?.label}</h2>
                    <span className="text-[10px] text-slate-500 font-medium">Command Center &gt; {currentItem?.label}</span>
                </div>
            </div>

            {/* Notification Bell */}
            <div className="relative">
                <button onClick={() => setIsNotifOpen(!isNotifOpen)} className="p-2 text-slate-500 hover:bg-slate-100 rounded-full transition-colors relative">
                    <Bell size={20} />
                    {notifications.length > 0 && <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"></span>}
                </button>

                {isNotifOpen && (
                    <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-100 z-50 animate-slideUp overflow-hidden">
                        <div className="p-3 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wide">Notifications</h3>
                            <span className="text-[10px] font-bold bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded-full">{notifications.length}</span>
                        </div>
                        <div className="max-h-80 overflow-y-auto">
                            {notifications.length === 0 ? (
                                <div className="p-8 text-center text-slate-400 text-sm">
                                    <Bell size={24} className="mx-auto mb-2 opacity-20"/>
                                    No new alerts
                                </div>
                            ) : (
                                notifications.map(n => (
                                    <button key={n.id} onClick={() => handleNotifClick(n)} className="w-full text-left p-4 hover:bg-slate-50 border-b border-slate-50 transition-colors flex gap-3">
                                        <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${n.type === 'success' ? 'bg-emerald-50' : n.type === 'warning' ? 'bg-amber-50' : 'bg-blue-50'}`}></div>
                                        <div>
                                            <p className="text-sm font-medium text-slate-800 leading-tight">{n.text}</p>
                                            <p className="text-xs text-slate-400 mt-1">Click to view</p>
                                        </div>
                                    </button>
                                ))
                            )}
                        </div>
                    </div>
                )}
            </div>
        </header>
        
        {/* Content Container - No Fixed Height */}
        <div className="flex-1 px-4 md:px-10 pb-12 pt-4 md:pt-8 w-full max-w-[1920px] mx-auto">
            {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;