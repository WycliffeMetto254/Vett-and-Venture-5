import React, { useState } from 'react';
import { UserRole } from '../types';
import { ArrowRight, Building2, User, Mail, Sparkles, CheckCircle2, Shield, Lock, ScanEye } from 'lucide-react';

interface LoginProps {
  onLogin: (role: UserRole, name: string, email: string, isRegistering: boolean, companyName?: string) => void;
}

// Professional "V" Logo for Vett & Venture
const Logo = () => (
    <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-xl">
        <rect width="48" height="48" rx="12" fill="url(#paint0_linear_logo)" />
        <path d="M24 34L11 13H17.5L24 24.5L30.5 13H37L24 34Z" fill="white"/>
        <path d="M24 6V10" stroke="white" strokeWidth="2" strokeLinecap="round"/>
        <defs>
            <linearGradient id="paint0_linear_logo" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
                <stop stopColor="#2563EB"/>
                <stop offset="1" stopColor="#06B6D4"/>
            </linearGradient>
        </defs>
    </svg>
);

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [role, setRole] = useState<UserRole>('founder');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [companyName, setCompanyName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email) {
        onLogin(role, name, email, mode === 'register', companyName);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans relative overflow-x-hidden selection:bg-blue-500 selection:text-white flex flex-col">
      {/* Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-[-10%] left-[-10%] w-[80vw] h-[80vw] max-w-[600px] max-h-[600px] bg-blue-600/20 rounded-full blur-[100px] animate-blob mix-blend-screen"></div>
          <div className="absolute bottom-[-10%] right-[-10%] w-[60vw] h-[60vw] max-w-[500px] max-h-[500px] bg-cyan-600/20 rounded-full blur-[100px] animate-blob animation-delay-2000 mix-blend-screen"></div>
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-10"></div>
      </div>

      <div className="relative z-10 flex flex-col flex-grow">
        
        {/* Navbar */}
        <nav className="px-4 py-6 md:px-6 flex justify-between items-center max-w-7xl mx-auto w-full">
            <div className="flex items-center gap-3">
                <Logo />
                <div className="flex flex-col">
                    <span className="text-white font-bold tracking-tight text-xl leading-none">Vett & Venture</span>
                    <span className="text-[10px] text-blue-300 font-bold uppercase tracking-widest mt-0.5">Platform</span>
                </div>
            </div>
            <div className="hidden md:flex gap-8 text-sm font-medium text-slate-400">
                <span className="hover:text-white cursor-pointer transition-colors">Manifesto</span>
                <span className="hover:text-white cursor-pointer transition-colors">Success Stories</span>
                <span className="hover:text-white cursor-pointer transition-colors">For Investors</span>
            </div>
        </nav>

        {/* Main Content */}
        <div className="flex-grow flex items-center justify-center p-4 md:p-8">
            <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center">
                
                {/* Left Column: Landing Copy */}
                <div className="text-center lg:text-left order-2 lg:order-1 pt-8 lg:pt-0">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/30 border border-blue-500/30 text-blue-300 text-xs font-bold uppercase tracking-wider mb-8 animate-fade-in backdrop-blur-sm shadow-sm">
                        <Sparkles size={12}/> Now Accepting Batch W25
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black text-white tracking-tight mb-8 leading-[1.1]">
                        Build the <br/>
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-400 animate-gradient">Impossible.</span>
                    </h1>
                    <p className="text-slate-400 text-lg md:text-xl leading-relaxed mb-10 max-w-lg mx-auto lg:mx-0">
                        The first AI-native accelerator. Go from idea to funded in 4 weeks with automated due diligence, legal generation, and instant investor matching.
                    </p>
                    
                    <div className="flex flex-wrap justify-center lg:justify-start gap-y-3 gap-x-8 text-sm font-medium text-slate-400 mb-12 lg:mb-0">
                        <div className="flex items-center gap-2.5">
                            <div className="p-1 bg-emerald-500/10 rounded-full"><CheckCircle2 className="text-emerald-500" size={16}/></div>
                            <span>$10M+ Capital Pool</span>
                        </div>
                        <div className="flex items-center gap-2.5">
                             <div className="p-1 bg-emerald-500/10 rounded-full"><CheckCircle2 className="text-emerald-500" size={16}/></div>
                            <span>0% Equity Fee</span>
                        </div>
                        <div className="flex items-center gap-2.5">
                             <div className="p-1 bg-emerald-500/10 rounded-full"><CheckCircle2 className="text-emerald-500" size={16}/></div>
                            <span>Global Remote</span>
                        </div>
                    </div>
                </div>

                {/* Right Column: Auth Card */}
                <div className="order-1 lg:order-2 w-full max-w-[440px] mx-auto lg:mr-0">
                    <div className="bg-slate-900/50 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/10 p-6 md:p-8 animate-fade-in relative overflow-hidden">
                        {/* Glow effect inside card */}
                        <div className="absolute -top-24 -right-24 w-48 h-48 bg-blue-500/20 rounded-full blur-3xl pointer-events-none"></div>
                        
                        <div className="mb-8 relative z-10">
                            <h2 className="text-2xl font-bold text-white mb-2">{mode === 'register' ? 'Join the Revolution' : 'Welcome Back'}</h2>
                            <p className="text-slate-400 text-sm">{mode === 'register' ? 'Apply for early access to Vett and Venture.' : 'Access your dashboard.'}</p>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-5 relative z-10">
                            {/* Role Toggle */}
                            <div className="grid grid-cols-3 gap-1 p-1 bg-slate-950/50 rounded-xl border border-white/5">
                                <button type="button" onClick={() => setRole('founder')} className={`py-2.5 rounded-lg text-xs font-bold flex flex-col items-center justify-center gap-1 transition-all border ${role === 'founder' ? 'bg-blue-600 border-blue-500 text-white shadow-lg' : 'border-transparent text-slate-500 hover:text-slate-300 hover:bg-white/5'}`}>
                                    <User size={16}/> Founder
                                </button>
                                <button type="button" onClick={() => setRole('analyst')} className={`py-2.5 rounded-lg text-xs font-bold flex flex-col items-center justify-center gap-1 transition-all border ${role === 'analyst' ? 'bg-blue-600 border-blue-500 text-white shadow-lg' : 'border-transparent text-slate-500 hover:text-slate-300 hover:bg-white/5'}`}>
                                    <ScanEye size={16}/> Analyst
                                </button>
                                <button type="button" onClick={() => setRole('investor')} className={`py-2.5 rounded-lg text-xs font-bold flex flex-col items-center justify-center gap-1 transition-all border ${role === 'investor' ? 'bg-blue-600 border-blue-500 text-white shadow-lg' : 'border-transparent text-slate-500 hover:text-slate-300 hover:bg-white/5'}`}>
                                    <Building2 size={16}/> Investor
                                </button>
                            </div>

                            <div className="space-y-4">
                                <div>
                                    <div className="relative group">
                                        <User className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={18} />
                                        <input type="text" required value={name} onChange={(e) => setName(e.target.value)} className="w-full pl-11 pr-4 py-3 bg-slate-950/50 border border-slate-700/50 rounded-xl focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 outline-none transition-all font-medium text-white placeholder:text-slate-600 text-sm" placeholder="Full Name" />
                                    </div>
                                </div>
                                
                                <div>
                                    <div className="relative group">
                                        <Mail className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={18} />
                                        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full pl-11 pr-4 py-3 bg-slate-950/50 border border-slate-700/50 rounded-xl focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 outline-none transition-all font-medium text-white placeholder:text-slate-600 text-sm" placeholder="Email Address" />
                                    </div>
                                </div>

                                {mode === 'register' && role === 'founder' && (
                                    <div className="animate-fade-in">
                                        <div className="relative group">
                                            <Shield className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={18} />
                                            <input type="text" value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="w-full pl-11 pr-4 py-3 bg-slate-950/50 border border-slate-700/50 rounded-xl focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 outline-none transition-all font-medium text-white placeholder:text-slate-600 text-sm" placeholder="Startup Name" />
                                        </div>
                                    </div>
                                )}
                            </div>

                            <button type="submit" className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40 transition-all hover:scale-[1.02] active:scale-[0.98] mt-2 border border-blue-400/20">
                                <span>{mode === 'register' ? 'Start Application' : 'Sign In'}</span>
                                <ArrowRight size={18} />
                            </button>
                        </form>

                        <div className="mt-8 text-center border-t border-white/5 pt-6 relative z-10">
                            <button onClick={() => setMode(mode === 'login' ? 'register' : 'login')} className="text-sm text-slate-400 hover:text-white transition-colors">
                                {mode === 'login' ? "Don't have an account? " : "Already have an account? "}
                                <span className="text-blue-400 font-bold hover:underline">{mode === 'login' ? 'Apply' : 'Log In'}</span>
                            </button>
                        </div>

                         {/* Quick Demo Login */}
                        <div className="mt-6 pt-4 border-t border-white/5 flex flex-col items-center gap-3 relative z-10">
                            <span className="text-[10px] text-slate-600 uppercase tracking-widest font-bold">Quick Demo Access</span>
                            <div className="flex flex-wrap justify-center gap-2">
                                <button onClick={() => { setMode('login'); setRole('founder'); setName('Alice Founder'); setEmail('alice@demo.com'); }} className="px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded-md text-[10px] text-blue-200 transition-colors border border-white/5 font-medium">Founder</button>
                                <button onClick={() => { setMode('login'); setRole('analyst'); setName('Sarah Analyst'); setEmail('sarah@vc.com'); }} className="px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded-md text-[10px] text-blue-200 transition-colors border border-white/5 font-medium">Analyst</button>
                                <button onClick={() => { setMode('login'); setRole('investor'); setName('Mike Investor'); setEmail('mike@vc.com'); }} className="px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded-md text-[10px] text-blue-200 transition-colors border border-white/5 font-medium">Investor</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {/* Website Footer */}
        <footer className="mt-auto border-t border-white/5 bg-slate-950/50 backdrop-blur-sm py-8 px-4">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
                 <div className="flex items-center gap-2.5 opacity-60">
                    <div className="w-6 h-6 rounded bg-blue-600 flex items-center justify-center"><Shield className="text-white" size={12}/></div>
                    <span className="text-white font-bold text-sm">Vett & Venture</span>
                </div>
                <div className="text-[10px] text-slate-600 flex gap-6">
                    <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
                    <span className="hover:text-slate-400 cursor-pointer">Terms of Service</span>
                    <span className="hover:text-slate-400 cursor-pointer">Contact Support</span>
                </div>
                <div className="text-[10px] text-slate-700">
                    &copy; 2024 Vett and Venture Inc.
                </div>
            </div>
        </footer>
      </div>
    </div>
  );
};
export default Login;