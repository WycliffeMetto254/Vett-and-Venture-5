import React, { useState } from 'react';
import { PitchData } from '../../types';
import { Save, ArrowLeft, Check, ChevronRight, PenTool } from 'lucide-react';

interface PitchDeckProps {
  pitchData: PitchData;
  setPitchData: (data: Partial<PitchData> & { id: string }) => void;
  onSave?: () => void;
  onExit?: () => void;
}

const PitchDeck: React.FC<PitchDeckProps> = ({ pitchData, setPitchData, onSave, onExit }) => {
  const sections: { id: keyof PitchData, label: string, desc: string }[] = [
    { id: 'companyName', label: 'Company Basics', desc: 'Identity & Vision' },
    { id: 'problem', label: 'The Problem', desc: 'What pain point are you solving?' },
    { id: 'solution', label: 'The Solution', desc: 'How do you solve it?' },
    { id: 'marketSize', label: 'Market Opportunity', desc: 'TAM, SAM, SOM analysis' },
    { id: 'businessModel', label: 'Business Model', desc: 'How do you make money?' },
    { id: 'team', label: 'The Team', desc: 'Why you?' },
  ];

  const [activeTab, setActiveTab] = useState<keyof PitchData>('companyName');
  const [saved, setSaved] = useState(false);

  const handleChange = (field: keyof PitchData, value: string) => {
      setPitchData({ id: pitchData.id, [field]: value });
      setSaved(false);
  };

  const handleSave = () => {
      setPitchData({ id: pitchData.id, lastUpdated: new Date().toISOString() });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
      if(onSave) onSave();
  };

  return (
    <div className="flex flex-col md:flex-row gap-6 max-w-7xl mx-auto pb-24">
        {/* Sidebar Nav - Stacks on mobile */}
        <div className="w-full md:w-80 flex-shrink-0 bg-white rounded-2xl border border-slate-200 overflow-hidden flex flex-col shadow-sm h-fit md:sticky md:top-24">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    {onExit && <button onClick={onExit} className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500"><ArrowLeft size={18}/></button>}
                    <h2 className="font-bold text-slate-800">Sections</h2>
                </div>
                <div className="text-xs font-semibold text-slate-400">{Math.round((Object.keys(pitchData).filter(k => (pitchData as any)[k]).length / 10) * 100)}%</div>
            </div>
            <div className="p-2 space-y-1">
                {sections.map(s => {
                    const isActive = activeTab === s.id;
                    const isFilled = !!(pitchData as any)[s.id];
                    return (
                        <button 
                            key={s.id} 
                            onClick={() => setActiveTab(s.id)}
                            className={`w-full text-left p-3 rounded-xl transition-all duration-200 flex items-center justify-between group ${isActive ? 'bg-brand-50 border-brand-200 ring-1 ring-brand-200' : 'hover:bg-slate-50 border border-transparent'}`}
                        >
                            <div>
                                <div className={`font-bold text-sm ${isActive ? 'text-brand-700' : 'text-slate-700'}`}>{s.label}</div>
                                <div className="text-[10px] text-slate-400 font-medium">{s.desc}</div>
                            </div>
                            {isFilled && !isActive && <div className="w-2 h-2 rounded-full bg-emerald-400"></div>}
                            {isActive && <ChevronRight size={16} className="text-brand-500"/>}
                        </button>
                    );
                })}
            </div>
            <div className="p-4 border-t border-slate-100 bg-slate-50">
                 <button onClick={handleSave} className={`w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${saved ? 'bg-emerald-500 text-white shadow-emerald-200' : 'bg-slate-900 text-white hover:bg-slate-800 shadow-slate-200'} shadow-lg`}>
                    {saved ? <Check size={18}/> : <Save size={18}/>}
                    {saved ? 'Saved Successfully' : 'Save Changes'}
                 </button>
            </div>
        </div>

        {/* Editor */}
        <div className="flex-1 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col relative min-h-[500px]">
            <div className="absolute top-0 left-0 w-full h-1 bg-slate-100 rounded-t-2xl overflow-hidden"><div className="h-full bg-brand-500 transition-all duration-300" style={{width: `${(sections.findIndex(s => s.id === activeTab) + 1) / sections.length * 100}%`}}></div></div>
            
            <div className="p-8 flex-1">
                 <div className="max-w-3xl mx-auto">
                    <div className="mb-6">
                        <span className="text-xs font-bold text-brand-600 uppercase tracking-wider bg-brand-50 px-2 py-1 rounded-md mb-2 inline-block">
                            Section {sections.findIndex(s => s.id === activeTab) + 1} of {sections.length}
                        </span>
                        <h2 className="text-3xl font-bold text-slate-900 mb-2">{sections.find(s => s.id === activeTab)?.label}</h2>
                        <p className="text-slate-500">{sections.find(s => s.id === activeTab)?.desc}</p>
                    </div>

                    {activeTab === 'companyName' ? (
                        <div className="space-y-12 animate-fadeIn">
                            <div className="group">
                                <label className="block text-sm font-bold text-slate-700 mb-2 group-focus-within:text-brand-600 transition-colors">Venture Name</label>
                                <input 
                                    type="text" 
                                    value={pitchData.companyName} 
                                    onChange={(e) => handleChange('companyName', e.target.value)}
                                    className="w-full text-4xl font-black border-b-2 border-slate-200 focus:border-brand-500 outline-none py-2 bg-transparent placeholder-slate-200 transition-colors"
                                    placeholder="Untitled"
                                />
                            </div>
                            <div className="group">
                                <label className="block text-sm font-bold text-slate-700 mb-2 group-focus-within:text-brand-600 transition-colors">Tagline</label>
                                <input 
                                    type="text" 
                                    value={pitchData.tagline} 
                                    onChange={(e) => handleChange('tagline', e.target.value)}
                                    className="w-full text-xl text-slate-600 border-b-2 border-slate-200 focus:border-brand-500 outline-none py-2 bg-transparent transition-colors"
                                    placeholder="Describe your value in one sentence..."
                                />
                            </div>
                        </div>
                    ) : (
                        <div className="relative group animate-fadeIn min-h-[400px]">
                             <PenTool className="absolute right-4 top-4 text-slate-300 pointer-events-none group-focus-within:text-brand-400 transition-colors" size={20} />
                             <textarea 
                                value={(pitchData as any)[activeTab] || ''} 
                                onChange={(e) => handleChange(activeTab, e.target.value)}
                                className="w-full h-full min-h-[400px] p-6 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-brand-500 focus:bg-white transition-all text-slate-700 leading-relaxed resize-none text-lg shadow-inner"
                                placeholder={`Detailed explanation of your ${activeTab}...`}
                            />
                        </div>
                    )}
                 </div>
            </div>
            
            <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-between items-center text-xs text-slate-400 rounded-b-2xl">
                <span>Last edited: {pitchData.lastUpdated ? new Date(pitchData.lastUpdated).toLocaleTimeString() : 'Just now'}</span>
                <span>{((pitchData as any)[activeTab] || '').length} chars</span>
            </div>
        </div>
    </div>
  );
};
export default PitchDeck;