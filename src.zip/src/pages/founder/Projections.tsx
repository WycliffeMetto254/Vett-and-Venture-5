import React, { useState, useEffect } from 'react';
import { PitchData, ProjectionData } from '../../types';
import { generateProjections } from '../../services/geminiService';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar, Line } from 'recharts';
import { ArrowLeft, AlertCircle, DollarSign, TrendingUp, TrendingDown, Activity } from 'lucide-react';

interface ProjectionsProps {
  pitchData: PitchData;
  setPitchData?: (data: Partial<PitchData> & { id: string }) => void;
  onExit?: () => void;
}

const SIMULATION_DATA: ProjectionData[] = [
    { year: "Year 1", revenue: 50000, expenses: 120000, users: 500, cac: 100, ltv: 300, burnRate: 15000, ebitda: -70000, grossMargin: 40 },
    { year: "Year 2", revenue: 250000, expenses: 200000, users: 2500, cac: 80, ltv: 450, burnRate: 10000, ebitda: -20000, grossMargin: 55 },
    { year: "Year 3", revenue: 800000, expenses: 450000, users: 15000, cac: 60, ltv: 600, burnRate: -5000, ebitda: 150000, grossMargin: 70 },
    { year: "Year 4", revenue: 2500000, expenses: 1200000, users: 80000, cac: 45, ltv: 800, burnRate: -100000, ebitda: 800000, grossMargin: 75 },
    { year: "Year 5", revenue: 8000000, expenses: 3500000, users: 300000, cac: 40, ltv: 1000, burnRate: -500000, ebitda: 2500000, grossMargin: 80 },
];

const Projections: React.FC<ProjectionsProps> = ({ pitchData, setPitchData, onExit }) => {
  const [loading, setLoading] = useState(false);
  const hasRealData = pitchData.projections && pitchData.projections.length > 0;
  const displayData = hasRealData ? pitchData.projections! : SIMULATION_DATA;
  const latest = displayData[displayData.length - 1];

  useEffect(() => {
    if (pitchData.companyName && !hasRealData && !loading) {
        setLoading(true);
        generateProjections(pitchData).then((d) => {
            if (setPitchData) setPitchData({ id: pitchData.id, projections: d && d.length ? d : SIMULATION_DATA });
        }).finally(() => setLoading(false));
    }
  }, [pitchData.companyName]); 

  const MetricCard = ({ title, value, sub, icon: Icon, color }: any) => (
      <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all">
          <div className="flex justify-between items-start mb-4">
              <div className={`p-3 rounded-xl ${color}`}>
                  <Icon size={20} />
              </div>
              <span className="text-xs font-bold uppercase text-slate-400 bg-slate-50 px-2 py-1 rounded">Year 5 Target</span>
          </div>
          <h3 className="text-3xl font-black text-slate-900 mb-1">{value}</h3>
          <p className="text-sm text-slate-500 font-medium">{title}</p>
          <div className="mt-4 pt-4 border-t border-slate-50 text-xs text-slate-400">
              {sub}
          </div>
      </div>
  );

  return (
    <div className="space-y-8 pb-12 font-sans max-w-7xl mx-auto">
      <div className="flex justify-between items-center">
        <div className="flex gap-4 items-center">
            {onExit && <button onClick={onExit} className="p-2 hover:bg-slate-100 rounded-full text-slate-500"><ArrowLeft size={20}/></button>}
            <div>
                <h1 className="text-2xl font-bold text-slate-900">Financial Intelligence</h1>
                <p className="text-slate-500 text-sm">5-Year Growth & Efficiency Models</p>
            </div>
        </div>
        {!hasRealData && <div className="bg-blue-50 px-4 py-2 rounded-lg flex gap-2 text-blue-700 text-sm font-bold border border-blue-100 items-center"><AlertCircle size={16}/><span>AI Simulation Model</span></div>}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard 
            title="LTV / CAC Ratio" 
            value={`${(latest.ltv && latest.cac ? (latest.ltv / latest.cac).toFixed(1) : 0)}x`} 
            sub="Efficiency Score" 
            icon={TrendingUp} 
            color="bg-emerald-50 text-emerald-600"
          />
           <MetricCard 
            title="Gross Margin" 
            value={`${latest.grossMargin}%`} 
            sub="Profitability Core" 
            icon={DollarSign} 
            color="bg-blue-50 text-blue-600"
          />
           <MetricCard 
            title="User Base" 
            value={`${(latest.users / 1000).toFixed(0)}k`} 
            sub="Scale Velocity" 
            icon={Activity} 
            color="bg-sky-50 text-sky-600"
          />
           <MetricCard 
            title="EBITDA" 
            value={`$${(latest.ebitda || 0 / 1000000).toFixed(1)}M`} 
            sub="Operating Profit" 
            icon={TrendingDown} 
            color="bg-amber-50 text-amber-600"
          />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Main Growth Chart */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-[400px] flex flex-col">
            <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2"><TrendingUp size={18} className="text-blue-500"/> Revenue vs Expenses Scale</h3>
            <div className="flex-1">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={displayData} margin={{top: 10, right: 10, left: 0, bottom: 0}}>
                        <defs>
                            <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorExp" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1}/>
                                <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9"/>
                        <XAxis dataKey="year" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false}/>
                        <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value/1000}k`}/>
                        <Tooltip contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px -2px rgba(0,0,0,0.1)'}}/>
                        <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" name="Revenue" />
                        <Area type="monotone" dataKey="expenses" stroke="#ef4444" strokeWidth={3} fillOpacity={1} fill="url(#colorExp)" name="Expenses" />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
        </div>

        {/* Profitability Chart */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-[400px] flex flex-col">
            <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2"><DollarSign size={18} className="text-emerald-500"/> EBITDA & Cash Flow</h3>
            <div className="flex-1">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={displayData} margin={{top: 10, right: 10, left: 0, bottom: 0}}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false}/>
                        <XAxis dataKey="year" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false}/>
                        <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value/1000}k`}/>
                        <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px -2px rgba(0,0,0,0.1)'}}/>
                        <Bar dataKey="ebitda" fill="#10b981" radius={[4, 4, 0, 0]} name="EBITDA" />
                        <Line type="monotone" dataKey="burnRate" stroke="#f59e0b" strokeWidth={2} dot={{r:4, fill:'#f59e0b'}} name="Burn Rate"/>
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
      </div>
    </div>
  );
};
export default Projections;