import { GoogleGenAI, Type } from "@google/genai";
import { PitchData, RoadmapTask, ProjectionData, Resource, Meeting, PitchAnalysis } from '../types';

const MODEL_NAME = 'gemini-3-flash-preview';

// Helper to clean markdown
const cleanText = (text: string) => text.replace(/[*#_`]/g, '').trim();

export const VESTA_RESOURCES: Resource[] = [
    {
        id: 'vesta-syllabus-core',
        title: 'Vett & Venture Foundations Bootcamp: The 28-Day Syllabus',
        type: 'book',
        description: 'The complete architectural blueprint for the Vett & Venture bootcamp.',
    },
    {
        id: 'vesta-code-conduct',
        title: 'Vett & Venture Founder Code of Conduct',
        type: 'article',
        description: 'Essential guidelines for maintaining integrity.',
    },
    {
        id: 'vesta-safe',
        title: 'SAFE (Simple Agreement for Future Equity) Template',
        type: 'tool',
        description: 'Standard YC-style SAFE agreement template.',
    },
    {
        id: 'vesta-ip',
        title: 'Intellectual Property Assignment Agreement',
        type: 'article',
        description: 'Standard legal framework ensuring all IP is assigned to the C-Corp.',
    },
    {
        id: 'vesta-ops-manual',
        title: 'The First 100 Days: A Founder\'s Operating Manual',
        type: 'book',
        description: 'A comprehensive guide to business development.',
    },
    {
        id: 'vesta-market-framework',
        title: 'Market Research & Validation Framework',
        type: 'tool',
        description: 'Templates and scripts for conducting customer interviews.',
    }
];

export const BOOTCAMP_RESOURCES: Resource[] = [
    {
        id: 'bootcamp-course-mgmt',
        title: 'Module 1: Agile Business Management for Startups',
        type: 'book',
        description: 'Course Work: A 40-page guide on managing small agile teams.',
    },
    {
        id: 'bootcamp-course-dev',
        title: 'Module 2: Technical Product Management',
        type: 'article',
        description: 'Course Work: Best practices for managing technical debt.',
    },
    {
        id: 'bootcamp-video-1',
        title: 'Week 1 Lecture: Architecture & Stress Testing',
        type: 'video',
        description: 'Deep dive into technical feasibility and MVP scoping.',
    },
    {
        id: 'bootcamp-template-1',
        title: 'Customer Discovery Script & Log',
        type: 'tool',
        description: 'The exact script to use for your 20 validation interviews.',
    },
    {
        id: 'bootcamp-book-1',
        title: 'The Mom Test (PDF)',
        type: 'book',
        description: 'How to talk to customers & learn if your business is a good idea.',
    },
    {
        id: 'bootcamp-template-finance',
        title: 'Unit Economics Calculator (SaaS + Marketplace)',
        type: 'tool',
        description: 'Plug-and-play spreadsheet to model your CAC, LTV, and burn rate.',
    }
];

export const analyzePitch = async (pitch: PitchData): Promise<PitchAnalysis> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `
      Analyze this startup pitch for a rigorous Venture Capital due diligence process.
      Company: ${pitch.companyName || "Untitled Startup"}
      Tagline: ${pitch.tagline || "N/A"}
      Problem: ${pitch.problem || "N/A"}
      Solution: ${pitch.solution || "N/A"}
      Market: ${pitch.marketSize || "N/A"}
      Business Model: ${pitch.businessModel || "N/A"}
      Team: ${pitch.team || "N/A"}
      
      Assess the startup based on these Critical Pillars: Market, Viability, Innovation, Team, Scalability, Competitive Advantage.
      Also assess: Regulatory Risk, Technical Feasibility, Market Timing, and Exit Potential.
      Return JSON with scores (0-100) and feedback.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overallScore: { type: Type.NUMBER },
            marketScore: { type: Type.NUMBER },
            viabilityScore: { type: Type.NUMBER },
            innovationScore: { type: Type.NUMBER },
            teamScore: { type: Type.NUMBER },
            scalabilityScore: { type: Type.NUMBER },
            advantageScore: { type: Type.NUMBER },
            regulatoryScore: { type: Type.NUMBER },
            techFeasibilityScore: { type: Type.NUMBER },
            marketTimingScore: { type: Type.NUMBER },
            exitPotentialScore: { type: Type.NUMBER },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
            feedback: { type: Type.STRING },
          },
          required: ['overallScore', 'marketScore', 'viabilityScore', 'innovationScore', 'teamScore', 'scalabilityScore', 'advantageScore', 'strengths', 'weaknesses', 'feedback']
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    const result = JSON.parse(text);
    return {
        ...result,
        feedback: cleanText(result.feedback)
    };
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return {
      overallScore: 0,
      marketScore: 0,
      viabilityScore: 0,
      innovationScore: 0,
      teamScore: 0,
      scalabilityScore: 0,
      advantageScore: 0,
      strengths: [],
      weaknesses: [],
      feedback: "Analysis failed. Please check your connection or API key."
    };
  }
};

export const getSamplePitch = (): PitchData => ({
  id: 'sample-ecodrone',
  companyName: "EcoDrone",
  tagline: "Reforestation at Scale using Autonomous Drones",
  problem: "Deforestation is happening faster than human planting can keep up.",
  solution: "We develop autonomous drone swarms capable of planting 100,000 seed pods per day.",
  marketSize: "The global reforestation market is valued at $5B and growing.",
  businessModel: "B2B Service model charging $0.50 per tree planted.",
  team: "Founded by a former SpaceX Flight Engineer and a PhD in Botany.",
  lastUpdated: new Date().toISOString(),
  stage: 'idea',
  meetings: []
});

export const generateMeetingAgenda = async (pitch: PitchData, meeting: Meeting): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `
      Act as a Lead Venture Capital Analyst. Create a high-stakes "Pitch Validation Review" agenda for the startup "${pitch.companyName}".
      
      DATA FROM PITCH:
      - Identified Problem: ${pitch.problem}
      - Proposed Solution: ${pitch.solution}
      - Target Market: ${pitch.marketSize}
      - Business Model: ${pitch.businessModel}
      - Team Background: ${pitch.team}

      Meeting Details: ${meeting.title}, Date: ${meeting.date}, Participants: ${meeting.participants.join(', ')}.

      The objective is to validate claims and expose risks. 
      
      GENERATE AN AGENDA COVERING THESE CRITICAL DILIGENCE PARAMETERS:
      1. PROBLEM-SOLUTION FIT: Validate if "${pitch.problem}" is acute enough to demand "${pitch.solution}".
      2. TECHNICAL & OPERATIONAL FEASIBILITY: Identify specific technical risks associated with the solution.
      3. BUSINESS MODEL STRESS-TEST: Interrogate "${pitch.businessModel}". Focus on Unit Economics (CAC vs LTV), Margins, and Recurring Revenue potential.
      4. MARKET DYNAMICS: "Why Now?" (Market Timing), Regulatory Hurdles, and Total Addressable Market reality check.
      5. COMPETITIVE LANDSCAPE & MOAT: Direct and indirect competitors. What is the unfair advantage?
      6. EXECUTION RISK: Supply chain vulnerabilities, hiring challenges, and go-to-market friction.
      7. CAP TABLE & FUNDRAISING: Capital efficiency and runway analysis.

      Output strictly plain text. No markdown, no bolding, no special characters like ## or **. Just clear numbered points and text.
    `;
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
    });
    return cleanText(response.text || "Failed to generate agenda.");
  } catch (error) {
    console.error("AI Agenda Generation Error:", error);
    return "Failed to generate agenda.";
  }
};

export const generateResources = async (pitch: PitchData): Promise<Resource[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `
      Suggest 4 specific resources (books, articles, tools) for: "${pitch.companyName}: ${pitch.solution}".
      Return JSON array.
    `;
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              title: { type: Type.STRING },
              type: { type: Type.STRING, enum: ['article', 'book', 'tool'] },
              description: { type: Type.STRING },
            },
            required: ['title', 'type', 'description']
          }
        }
      }
    });
    const text = response.text;
    const aiResources = text ? JSON.parse(text) : [];
    return [...VESTA_RESOURCES, ...aiResources].map((item, index) => ({ ...item, id: `res-${index}` }));
  } catch (error) {
    return VESTA_RESOURCES.map((item, index) => ({ ...item, id: `res-static-${index}` }));
  }
};

export const generateRoadmap = async (pitch: PitchData): Promise<RoadmapTask[]> => {
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `
            Create a "Day 1 to Launch" roadmap for ${pitch.companyName}.
            8-10 high-impact tasks. Categories: legal, product, marketing, operations.
            Return JSON array.
        `;
        const response = await ai.models.generateContent({
            model: MODEL_NAME,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            id: { type: Type.STRING },
                            day: { type: Type.NUMBER },
                            title: { type: Type.STRING },
                            description: { type: Type.STRING },
                            completed: { type: Type.BOOLEAN },
                            category: { type: Type.STRING, enum: ['legal', 'product', 'marketing', 'operations'] }
                        },
                        required: ['day', 'title', 'description', 'category']
                    }
                }
            }
        });
        const text = response.text;
        return text ? JSON.parse(text) : [];
    } catch (e) {
        return [
            { id: '1', day: 1, title: 'Legal Incorporation', description: 'File Certificate of Incorporation.', completed: false, category: 'legal' }
        ];
    }
};

export const generateBootcampContent = async (title: string, type: string, companyName: string): Promise<string> => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Generate educational content for startup bootcamp module: "${title}" (${type}) for ${companyName}. 300 words. Plain text. No markdown.`;
      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
      });
      return cleanText(response.text || "Content generation failed.");
    } catch (error) {
      return "Unable to generate content.";
    }
};

export const generateProjections = async (pitch: PitchData): Promise<ProjectionData[]> => {
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `Generate 5-year financial projection for ${pitch.companyName}. 
        Return JSON array of objects with:
        year (string "Year 1"), revenue (number), expenses (number), users (number),
        cac (number), ltv (number), burnRate (number), ebitda (number), grossMargin (number).
        Ensure numbers are realistic for a VC-backed startup.`;
        
        const response = await ai.models.generateContent({
            model: MODEL_NAME,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            year: { type: Type.STRING },
                            revenue: { type: Type.NUMBER },
                            expenses: { type: Type.NUMBER },
                            users: { type: Type.NUMBER },
                            cac: { type: Type.NUMBER },
                            ltv: { type: Type.NUMBER },
                            burnRate: { type: Type.NUMBER },
                            ebitda: { type: Type.NUMBER },
                            grossMargin: { type: Type.NUMBER }
                        },
                        required: ['year', 'revenue', 'expenses', 'users', 'cac', 'ltv', 'burnRate', 'ebitda', 'grossMargin']
                    }
                }
            }
        });
        const text = response.text;
        if (!text) throw new Error("No projection data");
        return JSON.parse(text);
    } catch (error) {
        return Array.from({ length: 5 }, (_, i) => ({
            year: `Year ${i + 1}`,
            revenue: 100000 * Math.pow(2.5, i),
            expenses: 80000 * Math.pow(2.5, i),
            users: Math.floor(1000 * Math.pow(3, i)),
            cac: 50,
            ltv: 500,
            burnRate: 20000,
            ebitda: -50000 + (i * 20000),
            grossMargin: 60
        }));
    }
};