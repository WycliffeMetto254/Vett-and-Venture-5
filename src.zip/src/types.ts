export type UserRole = 'founder' | 'investor' | 'analyst';
export type StartupStage = 'idea' | 'validation' | 'contract' | 'bootcamp' | 'funded';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  email: string;
}

export interface Meeting {
  id: string;
  title: string;
  date: string;
  participants: string[];
  agenda?: string;
  agendaLastUpdated?: string;
  status?: 'scheduled' | 'confirmed' | 'rescheduled' | 'approved' | 'completed';
}

export interface PitchAnalysis {
  overallScore: number;
  marketScore: number;
  viabilityScore: number;
  innovationScore: number;
  teamScore: number;
  scalabilityScore: number;
  advantageScore: number;
  regulatoryScore?: number;
  techFeasibilityScore?: number;
  marketTimingScore?: number;
  exitPotentialScore?: number;
  gritScore?: number;
  gritFeedback?: string;
  strengths: string[];
  weaknesses: string[];
  feedback: string;
}

export interface PhysicalDetails {
  address: string;
  mapLink: string;
  employeeCount: number;
  officeType: 'remote' | 'leased' | 'owned' | 'coworking';
  verifiedAt: string;
}

export interface PitchData {
  id: string;
  companyName: string;
  tagline: string;
  problem: string;
  solution: string;
  marketSize: string;
  businessModel: string;
  team: string;
  lastUpdated?: string;
  stage: StartupStage;
  contractSignedDate?: string;
  contractSignature?: string;
  analystSignature?: string;
  analystSignedDate?: string;
  bootcampCurrentWeek?: number;
  meetings?: Meeting[];
  resources?: Resource[];
  roadmap?: RoadmapTask[];
  roadmapConfirmed?: boolean;
  analysis?: PitchAnalysis; 
  bootcampContent?: Record<string, string>;
  physicalDetails?: PhysicalDetails;
  projections?: ProjectionData[];
}

export interface Resource {
  id: string;
  title: string;
  type: 'article' | 'book' | 'video' | 'tool';
  description: string;
  link?: string;
}

export interface RoadmapTask {
  id: string;
  day: number;
  title: string;
  description: string;
  completed: boolean;
  category: 'legal' | 'product' | 'marketing' | 'operations';
}

export interface ProjectionData {
  year: string;
  revenue: number;
  expenses: number;
  users: number;
  cac?: number;
  ltv?: number;
  burnRate?: number;
  ebitda?: number;
  grossMargin?: number;
}